package 연상퀴즈게임팀플.copy;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.List;
import javax.swing.*;
import java.net.Socket;

public class PlayerGUI extends JFrame {

    private static final int TOTAL_TIME_LIMIT = 250; // 총 퀴즈 제한 시간
    private static final int HINT_TIME_INTERVAL = 5; // 힌트 제공 간격
    private static final int NEXT_QUIZ_TIME = 50;    // 다음 문제로 넘어가는 시간

    private Timer mainTimer;  // 메인 타이머 (퀴즈 진행 타이머)
    private Timer hintTimer;  // 힌트 타이머
    private Timer delayTimer; // 시작 지연 타이머
    private int totalQuizTime;    // 현재 문제의 남은 시간
    private int hintIndex = 0;    // 현재 제공된 힌트 인덱스
    private int currentQuizIndex = 0; // 현재 퀴즈 인덱스

    private List<Quiz> selectedQuestions; // 퀴즈 데이터
    private ReadQuizFile rqf = new ReadQuizFile(); // JSON 파일 읽기 객체

    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;

    
    // GUI 컴포넌트
    private JTextArea chatOutputArea;  // 채팅 출력 영역
    private JTextField timerField;     // 타이머 표시 영역
    private JTextField questionField;  // 남은 문제 표시
    private JTextArea rankField;       // 기록 표시 영역
    private JPanel mainPanel;          // 메인 패널

    public PlayerGUI() {
        // 퀴즈 데이터를 JSON 파일에서 읽기
        selectedQuestions = rqf.readQuizFile();

        // JFrame 설정
        setTitle(":: Association Quiz ::");
        setSize(600, 550);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        // ** 메인 패널 설정 **
        mainPanel = new JPanel();
        mainPanel.setLayout(null); // 절대 레이아웃
        mainPanel.setBounds(0, 0, 600, 550);
        mainPanel.setBackground(new Color(245, 245, 245));
        add(mainPanel);

        // ** 중앙 패널: 채팅 영역 **
        chatOutputArea = new JTextArea();
        chatOutputArea.setBounds(40, 20, 300, 400);
        chatOutputArea.setEditable(false);
        chatOutputArea.setBackground(Color.WHITE);
        chatOutputArea.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        JScrollPane chatScrollPane = new JScrollPane(chatOutputArea);
        chatScrollPane.setBounds(40, 20, 300, 400);
        mainPanel.add(chatScrollPane);

        JTextField chatInputField = new JTextField();
        chatInputField.setBounds(40, 440, 300, 40);
        chatInputField.setFont(new Font("굴림", Font.PLAIN, 18));
        chatInputField.setHorizontalAlignment(JTextField.CENTER);
        chatInputField.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        mainPanel.add(chatInputField);

        // ** 오른쪽 패널: 타이머, 남은 문제, 기록 영역 **
        JLabel timerTitle = new JLabel("남은 시간", SwingConstants.CENTER);
        timerTitle.setBounds(370, 30, 180, 30);
        timerTitle.setFont(new Font("굴림", Font.BOLD, 16));
        mainPanel.add(timerTitle);

        timerField = new JTextField("" + TOTAL_TIME_LIMIT);
        timerField.setBounds(370, 60, 180, 60);
        timerField.setFont(new Font("굴림", Font.BOLD, 40));
        timerField.setHorizontalAlignment(JTextField.CENTER);
        timerField.setEditable(false);
        timerField.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        mainPanel.add(timerField);

        JLabel questionTitle = new JLabel("남은 문제", SwingConstants.CENTER);
        questionTitle.setBounds(370, 140, 180, 30);
        questionTitle.setFont(new Font("굴림", Font.BOLD, 16));
        mainPanel.add(questionTitle);

        questionField = new JTextField((currentQuizIndex + 1) + "/" + selectedQuestions.size());
        questionField.setBounds(370, 170, 180, 40);
        questionField.setFont(new Font("굴림", Font.BOLD, 16));
        questionField.setHorizontalAlignment(JTextField.CENTER);
        questionField.setEditable(false);
        questionField.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        mainPanel.add(questionField);

        JLabel rankTitle = new JLabel("기록", SwingConstants.CENTER);
        rankTitle.setBounds(370, 220, 180, 30);
        rankTitle.setFont(new Font("굴림", Font.BOLD, 16));
        mainPanel.add(rankTitle);

        rankField = new JTextArea("1위: 홍길동\n2위: 김철수\n3위: 이순신");
        rankField.setBounds(370, 260, 180, 70);
        rankField.setFont(new Font("굴림", Font.BOLD, 18));
        rankField.setEditable(false);
        rankField.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        mainPanel.add(rankField);

        // ** START 버튼 **
        JButton startButton = new JButton("★START★");
        startButton.setBounds(370, 370, 180, 50);
        startButton.setFont(new Font("굴림", Font.BOLD, 18));
        startButton.setBackground(new Color(60, 179, 113));
        startButton.setForeground(Color.WHITE);
        mainPanel.add(startButton);

        // ** EXIT 버튼 **
        JButton exitButton = new JButton("★EXIT★");
        exitButton.setBounds(370, 430, 180, 50);
        exitButton.setFont(new Font("굴림", Font.BOLD, 18));
        exitButton.setBackground(new Color(220, 20, 60));
        exitButton.setForeground(Color.WHITE);
        mainPanel.add(exitButton);

        // ** 채팅 입력 이벤트 리스너 **
        chatInputField.addActionListener(e -> {
            String message = chatInputField.getText(); // 입력된 텍스트 가져오기
            chatOutputArea.append(message + "\n");    // 채팅 출력창에 추가
            chatInputField.setText("");               // 입력 필드 초기화
            sendMessageToServer(message); //채팅 내용을 서버로************

        });

        // ** START 버튼 이벤트 **
        startButton.addActionListener(e -> {
            startQuizWithDelay();
        });

        // ** EXIT 버튼 이벤트 **
        exitButton.addActionListener(e -> System.exit(0));

        setVisible(true);
        
        
        try {
            // 서버에 연결
            socket = new Socket("localhost", 12345); // 서버 IP와 포트를 설정
            out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), "UTF-8"), true);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream(), "UTF-8"));
            
            // 서버로부터 메시지 수신 처리
            new Thread(() -> {
                try {
                    String message;
                    while ((message = in.readLine()) != null) {
                        chatOutputArea.append(message + "\n"); // 받은 메시지를 채팅 창에 표시
                        processServerMessage(message); // 받은 메시지 처리

                    }
                } catch (IOException e) {
                    chatOutputArea.append("서버 연결이 종료되었습니다.\n");
                }
            }).start();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "서버에 연결할 수 없습니다.", "Error", JOptionPane.ERROR_MESSAGE);
            System.exit(0);
    
        }
        
     // START 버튼 이벤트
        startButton.addActionListener(e -> {
            sendMessageToServer("START"); // 서버에 퀴즈 시작 요청 전송
        });

        // 채팅 입력 이벤트
        chatInputField.addActionListener(e -> {
            String message = chatInputField.getText();
            sendMessageToServer("ANSWER|" + message); // 서버에 답변 전송
            chatInputField.setText(""); // 입력 필드 초기화
        });
        
        
        
    }
    
        
    public void processServerMessage(String message) {
        try {
            // 메시지를 |로 분리
            String[] parts = message.split("\\|");
            String command = parts[0];

            switch (command) {
                case "QUIZ":
                    handleQuizMessage(parts);
                    break;
                case "ANSWER":
                    handleAnswerMessage(parts);
                    break;
                case "SCORE":
                    handleScoreMessage(parts);
                    break;
                default:
                    System.out.println("Unknown command: " + command);
            }
        } catch (Exception e) {
            System.err.println("Failed to process message: " + e.getMessage());
        }
    }

    // QUIZ 메시지 처리
    private void handleQuizMessage(String[] parts) {
        if (parts.length < 3) {
            System.err.println("Invalid QUIZ message format");
            return;
        }
        String answer = parts[1];
        String[] hints = parts[2].split(",");
        System.out.println("QUIZ Received!");
        System.out.println("Answer: " + answer);
        System.out.println("Hints: ");
        for (String hint : hints) {
            System.out.println("- " + hint);
        }
    }

    // ANSWER 메시지 처리
    private void handleAnswerMessage(String[] parts) {
        if (parts.length < 3) {
            System.err.println("Invalid ANSWER message format");
            return;
        }
        String username = parts[1];
        String answer = parts[2];
        System.out.println(username + " submitted the answer: " + answer);
    }

    // SCORE 메시지 처리
    private void handleScoreMessage(String[] parts) {
        if (parts.length < 3) {
            System.err.println("Invalid SCORE message format");
            return;
        }
        String username = parts[1];
        String score = parts[2];
        System.out.println("Score Update for " + username + ": " + score);
    }

   
        
 // 채팅 입력 이벤트 처리
    private void sendMessageToServer(String message) {
        if (out != null) {
            out.println(message); // 서버로 메시지 전송
        }
    }
    

    // 퀴즈 시작 메서드 (3초 지연 후 타이머 시작)
    private void startQuizWithDelay() {
        totalQuizTime = TOTAL_TIME_LIMIT;
        hintIndex = 0;

        chatOutputArea.append("퀴즈가 곧 시작됩니다! 잠시만 기다려주세요...\n");

        delayTimer = new Timer(1000, new ActionListener() {
            int delayCount = 3; // 3초 지연

            @Override
            public void actionPerformed(ActionEvent e) {
                if (delayCount > 0) {
                    chatOutputArea.append("시작까지 " + delayCount + "초 남았습니다...\n");
                    delayCount--;
                } else {
                    delayTimer.stop(); // 지연 타이머 종료
                    chatOutputArea.append("퀴즈가 시작됩니다! 첫 번째 힌트를 확인하세요.\n");
                    startQuiz();
                }
            }
        });
        delayTimer.start();
    }

    // 퀴즈 진행 메서드
    private void startQuiz() {
        totalQuizTime = TOTAL_TIME_LIMIT;

        // 첫 번째 힌트 즉시 제공
        provideHint();

        // 5초 간격으로 힌트를 제공하는 타이머
        hintTimer = new Timer(HINT_TIME_INTERVAL * 1000, e -> provideHint());
        hintTimer.start();

        // 메인 타이머 시작
        mainTimer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                totalQuizTime--;

                // 타이머 UI 업데이트
                timerField.setText("" + totalQuizTime);

                // 50초마다 다음 문제로 전환
                if (totalQuizTime % NEXT_QUIZ_TIME == 0) {
                    moveToNextQuiz();
                }

                // 타이머 종료
                if (totalQuizTime <= 0) {
                    mainTimer.stop();
                    hintTimer.stop(); // 힌트 타이머도 종료
                    JOptionPane.showMessageDialog(PlayerGUI.this, "퀴즈가 종료되었습니다!");
                }
            }
        });
        mainTimer.start();
    }

    // 힌트를 제공하는 메서드
    private void provideHint() {
        Quiz currentQuiz = selectedQuestions.get(currentQuizIndex);
        if (hintIndex < currentQuiz.getHints().size()) {
            chatOutputArea.append("힌트: " + currentQuiz.getHints().get(hintIndex) + "\n");
            hintIndex++;
        }
    }

    // 다음 문제로 이동
    private void moveToNextQuiz() {
        currentQuizIndex++;
        if (currentQuizIndex < selectedQuestions.size()) {
            chatOutputArea.append("\n다음 문제로 넘어갑니다!\n");
            questionField.setText((currentQuizIndex + 1) + "/" + selectedQuestions.size());
            hintIndex = 0;
            totalQuizTime = TOTAL_TIME_LIMIT;
            provideHint(); // 첫 번째 힌트 제공
        } else {
            mainTimer.stop();
            hintTimer.stop(); // 힌트 타이머도 종료
            chatOutputArea.append("\n모든 문제가 종료되었습니다!\n");
        }
    }

    
    
    
    
    
    // 메인 메서드
    public static void main(String[] args) {
        SwingUtilities.invokeLater(PlayerGUI::new);
    }
}
