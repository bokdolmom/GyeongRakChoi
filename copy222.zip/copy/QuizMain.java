package 연상퀴즈게임팀플.copy;

public class QuizMain {

	public QuizMain() {

	}

}
