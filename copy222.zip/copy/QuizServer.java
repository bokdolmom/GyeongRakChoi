package 연상퀴즈게임팀플.copy;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class QuizServer {
	
	// 서버가 관리하는 클라이언트핸들러의 리스트
	// 하나만 있으면 되니까 static
	
 public static synchronized void broadcast(String message) {//브로드캐스트
	    for (ClientHandler clientHandler : clients) {
	        clientHandler.sendMessage(message); // ClientHandler의 sendMessage 메서드 호출
	    }
	}	
 
	private static List<ClientHandler> clients
		= new ArrayList<ClientHandler>();
	
	private static final int PORT = 12345; // 서버에서 사용할 포트 번호
	
	
	
	
	public static void main(String[] args) {//main
		
		

		System.out.println("퀴즈게임 서버를 시작합니다");//나의 콘솔에만 보임
		
		broadcast("퀴즈게임 서버를 시작합니다!"); //모든 클라이언트 들에게 보임

		ClientHandler clientHandler = null;		
		
		try {
		
			// ServerSocket 생성
			ServerSocket connectSocket = new ServerSocket(PORT);
			  System.out.println("서버가 포트 " + PORT + "에서 실행 중입니다.");
			  broadcast("서버가 포트" + PORT + " 에서 실행 중입니다.");
			  
			  
			if (connectSocket != null) {
				System.out.println("서버 시작됨. 클라이언트 대기중!");
			   broadcast("서버 시작됨. 클라이언트 대기중!");

			}
			 
			while (true) {
				// 클라이언트 연결요청 대기
				// 연결요청이 오면 클라이언트소켓과 데이터 송수신하는 서버소켓을 생성
				Socket serverSocket = connectSocket.accept();
				System.out.println("클라이언트 접속 : " + serverSocket);
			   broadcast("클라이언트 접속 : " + serverSocket);

				// 클라이언트핸들러 생성
				// 클라이언트마다 다른 클라이언트들과 데이터 송수신할 수 있도록 클라이언트핸들러 생성
				// serverSocket 1개는 서버에서 관리하는 클라이언트 1
				// clients : 서버에서 관리하는 클라이언트핸들러 리스트
				clientHandler = new ClientHandler(serverSocket, clients);
				
				// 클라이언트핸들러리스트에 클라이언트핸들러 추가
				clients.add(clientHandler);
				
				// 쓰레드 생성해서 시작 = 데이터 송수신 시작
				new Thread(clientHandler).start();
			}
			
		} catch (IOException ioe) {
			ioe.printStackTrace();
			// 클라이언트핸들러리스트에서 클라이언트핸들러 제거
			clients.remove(clientHandler);
		}
		
	} // main

} // class
