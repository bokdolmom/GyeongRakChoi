package 연상퀴즈게임팀플.copy;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

// 점수를 계산하고 계산된 점수를 토대로 등수 계산
// 각 문제 별로 남은 시간을 가져와 점수를 합산
// 합산 한 점수를 토대로 ScoreFile의 내용과 점수를 비교
// 이미 입력된 점수들 보다 높은 점수를 기록시 등수를 변경
public class GameRule {
	
	static void gameRule() {
		List<User> userList = SaveScoreFile.readScoreFile();
		
	}
	
	public static void main(String[] args) {
		
		List<User> userList = new ArrayList<User>();
		userList.addAll(SaveScoreFile.readScoreFile());
		
		// 게임 플레이후 GUI에서 입력받은 이름과 점수를 입력하는것으로 대체 될 예정
		userList.add(new User("SON",130));
		
		Comparator<User> intcom = new Comparator<User>() {
			
			@Override
			public int compare(User u1, User u2) {
				return u2.getScore()-u1.getScore();
			}
		};
		
		Collections.sort(userList, intcom);
		userList.remove(3);
		
		SaveScoreFile.writeScoreFile(userList);
		
		
		for (User user : userList) {
			System.out.println(user);
		}
	}// main
	
}// class